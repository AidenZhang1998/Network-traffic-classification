import copy
from sklearn.model_selection import KFold

import numpy as np
import tensorflow as tf
import random
import os
#from tensorflow.keras import layers, models
import matplotlib.pyplot as plt
import re
import cv2 as cv

from tensorflow import keras

randomseed = 7
np.random.seed(randomseed)

datapath = "E:\\DL\\Cross-validationNoVpnTo10\\TransformImage\\image"
testpath = "E:\\DL\\OversamplingNoVpnTo10\\TransformImage\\test"
labeldict = {}


def train_image(path, classname=None):
    count = 0
    templabels = [0 for i in range(10)]
    images = []
    labels = []
    imagenamelist = []
    if classname == None:
        imagenamelist = [path + "\\" + name for name in os.listdir(path) if name.lower().endswith('jpg')]
    else:
        imagenamelist = [path + "\\" + name for name in os.listdir(path) if
                         name.lower().endswith('jpg') and name.lower().startswith(classname)]
    random.shuffle(imagenamelist)
    random.shuffle(imagenamelist)

    for i in imagenamelist:
        image = cv.imread(i, flags=0)
        # image = cv.cvtColor(image,cv.COLOR_BGR2GRAY)
        # print(image.shape)
        image = image[:, :, np.newaxis]
        # print(image.shape,image)
        images.append(image)
        pattern = re.compile('^[a-z]+')
        vpnpattern = re.compile('(vpn_[a-z]+)')
        name = i.split('\\')[-1]
        if name.startswith('vpn'):
            name = vpnpattern.findall(name.lower())[0]
        else:
            name = pattern.findall(name.lower())[0]
        # print('label name',name)
        if name in labeldict:
            label = labeldict[name]
            labels.append(label)
            count += 1
        else:
            labellength = len(labeldict)
            templabel = copy.deepcopy(templabels)
            templabel[labellength] = 1
            labeldict.update({name: templabel})
            label = templabel
            labels.append(label)
            count += 1
        # if count %10000 == 0:
        #     print("处理完{}个图片".format(count))
    images = np.array(images)
    images = images / 255.0
    labels = np.array(labels)
    # print(images.shape,labeldict)
    return images, labels
def create_model():
    model = tf.keras.models.Sequential([
    keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(32, 32, 1)),
    keras.layers.MaxPooling2D((2, 2)),
    keras.layers.Conv2D(64, (3, 3), activation='relu'),
    keras.layers.MaxPooling2D((2, 2)),
    keras.layers.Conv2D(64, (3, 3), activation='relu'),
    keras.layers.Flatten(),
    keras.layers.Dense(64, activation='relu'),
    keras.layers.Dense(10)
    ])
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),
                  loss=tf.keras.losses.CategoricalCrossentropy(from_logits=True),
                  metrics=['accuracy'])
    return model

train_images, train_labels = train_image(datapath)
# print(train_images,train_labels)
# print(test_images,test_labels)
X = train_images
Y = train_labels
kf = KFold(n_splits=10, shuffle=True, random_state=randomseed)
cvscores = []
model = create_model()
model.summary()
model.save('my_model.h5')
for train, test in kf.split(X, Y):
    # print(np.array(X)[train], np.array(Y)[train])
    train_images = np.array(X)[train]
    train_labels = np.array(Y)[train]
    # print(np.array(X)[test], np.array(Y)[test])
    test_images = np.array(X)[test]
    test_labels = np.array(Y)[test]
    new_model = keras.models.load_model('my_model.h5')
    history = model.fit(train_images, train_labels, epochs=5, validation_split=0.1
                        )
    model.save('my_model.h5')
    plt.plot(history.history['accuracy'], label='accuracy')
    plt.plot(history.history['val_accuracy'], label='val_accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.ylim([0, 1])
    plt.legend(loc='lower right')
    plt.show()
    test_loss, test_acc = model.evaluate(test_images, test_labels, verbose=0)
    print(test_loss, test_acc)
    # scores = model.evaluate(test_images, test_images, verbose=0)
    # print("%s: %.2f%%" % (model.metrics_names[1], scores[1] * 100))
    cvscores.append(test_acc * 100)

print((np.min(cvscores), np.average(cvscores)))
